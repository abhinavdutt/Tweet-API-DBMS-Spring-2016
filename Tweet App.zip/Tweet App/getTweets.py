# Import the necessary package to process data in JSON format
try:
    import json
except ImportError:
    import simplejson as json

from twitter import Twitter, OAuth, TwitterHTTPError, TwitterStream
from pymongo import MongoClient

# Import the necessary methods from "twitter" library
from twitter import Twitter, OAuth, TwitterHTTPError, TwitterStream

# Variables that contains the user credentials to access Twitter API 
ACCESS_TOKEN = '3223497200-RMtorgiVrwXo2Ha79CwrPqQsIk8eSIAmhGtxeQ0'
ACCESS_SECRET = 'yp4S4KqAKTNd6oLUcvaVEjNnTEcZxnuVXQ7BSaa0XU6TA'
CONSUMER_KEY = '4f8d2qgkvOI7KomKLVELIGyQv'
CONSUMER_SECRET = 'JzIUWSR9RHJDYYloY7z7jD62A7ej6J8ii3F49IU0vkIhqVQlM9'

oauth = OAuth(ACCESS_TOKEN, ACCESS_SECRET, CONSUMER_KEY, CONSUMER_SECRET)

# Initiate the connection to Twitter Streaming API
twitter_stream = TwitterStream(auth=oauth)


iterator = twitter_stream.statuses.sample()
iterator = twitter_stream.statuses.filter(track="USA", language="en")


client = MongoClient()

client = MongoClient("mongodb://localhost:27017")

db = client.test


tweet_count = 10
for tweet in iterator:
    tweet_count -= 1
    # Twitter Python Tool wraps the data returned by Twitter
    # as a TwitterDictResponse object.
    # We convert it back to the JSON format to print/score
    print json.dumps(tweet)

    result = tweet

    db.tweets.insert(result)

    # The command below will do pretty printing for JSON data, try it out
    # print json.dumps(tweet, indent=4)

    if tweet_count <= 0:
        break 

client.close()
