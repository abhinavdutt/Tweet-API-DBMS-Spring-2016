import tkMessageBox

from pymongo import MongoClient
from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk

class Twitter:
  def __init__(self,master):
    self.frame1= Frame(master, width=200, height=100)
    self.frame1.pack(fill=None,expand=False)
    image = Image.open("twitter_logo.png")
    self.logo = ImageTk.PhotoImage(image)

    self.label1 = ttk.Label(self.frame1, image=self.logo).grid(row=3, column=0, columnspan=25)
    self.heading=ttk.Label(self.frame1,text="Tweet App",font=("Helvetica", 20))
    self.heading.grid(row=5, column=0, columnspan=25)

    self.button2 = Button(self.frame1, text="Get latest Tweets", command=self.getTweets, height=4, width=40, background="#3366ff", foreground="white", font="8")
    self.button2.grid(row=8, column=0, columnspan=25)
    self.button3 = Button(self.frame1, text="View Tweets",command=self.view_tweets, height=4, width=40,background="white", font="8")
    self.button3.grid(row=11, column=0, columnspan=25)

  def getTweets(self):
    execfile("getTweets.py")
    tkMessageBox.showinfo("Tweet App","Got the latest tweets successfully...!")

  def view_tweets(self):
    Twitter=Tk()
    twitter1=Twitter1(Twitter)
    twitter1.frame2.tkraise()
    Twitter.mainloop()

class Twitter1:
    def displaytweets(self):

        self.tweets.delete("1.0", END)
        client = MongoClient()

        client = MongoClient("mongodb://localhost:27017")

        db = client.test
        self.tweets.insert(INSERT, "   Displaying ALL Tweets.... \n")
        self.tweets.insert(INSERT, ":::::::::::::::::::::::::::::::::::::::::::::::: " + "\n\n")

        cursor = db.tweets.find()
        for document in cursor:
            try:
                tweet = document
                if 'text' in tweet:
                    self.tweets.insert(INSERT, "  Screen Name::: " + tweet['user']['screen_name'] + "\n")
                    self.tweets.insert(INSERT, "  Text::: " + tweet['text'] + "\n")
                    self.tweets.insert(INSERT, "  Created at::: " + tweet['created_at'] + "\n")
                    self.tweets.insert(INSERT,
                                       "--------------------------------------------------------------------\n\n")

            except:
                continue


    def __init__(self,master):
        self.frame2= ttk.Frame(master, width=200, height=50)
        self.frame2.pack()
        self.searchbox=ttk.Entry(self.frame2)
        self.searchbox.grid(row=1,column=0)
        self.button1 = Button(self.frame2, text="Search", command=self.searchtweets,background="#3366ff", foreground="white", font="8")
        self.button1.grid(row=6, column=0,stick='NEWSE')
        self.button2 = Button(self.frame2, text="Show All Tweets", command=self.displaytweets,background="#3366ff", foreground="white", font="8")
        self.button2.grid(row=10, column=0)
        Type = StringVar()
        self.searchby=ttk.Label(self.frame2,text="Search by: ")
        self.searchby.grid(row=2,column=0)
        self.combobox = ttk.Combobox(self.frame2, textvariable=Type, )
        self.combobox.grid(row=3,column=0)
        self.combobox.config(values=('Text','Hashtag', 'Date', 'Screen Name'))
        self.combobox.current(0)
        self.tweets= Text(self.frame2,width=150,height=40)
        self.tweets.grid(row=0,rowspan=20, column=1)
        scrollb = ttk.Scrollbar(self.frame2, command=self.tweets.yview)
        scrollb.grid(row=0, rowspan=20, column=2, sticky='nsew', )
        self.tweets['yscrollcommand'] = scrollb.set
        self.displaytweets()

    def searchtweets(self):
          self.tweets.delete("1.0", END)
          keyword=self.searchbox.get()
          searchby=self.combobox.get()

          client = MongoClient()

          client = MongoClient("mongodb://localhost:27017")

          db = client.test

          if 'Text' in searchby:
              cursor = db.tweets.find()
              self.tweets.insert(INSERT,"    Showing Records searched by Text: "+ keyword+"\n")
              self.tweets.insert(INSERT,"  ------------------------------------------\n\n")
              for document in cursor:
                  try:
                      tweet = document
                      if 'text' in tweet:
                          if keyword in tweet['text']:
                              # only messages contains 'text' field is a tweet
                              self.tweets.insert(INSERT, "Screen Name::: " + tweet['user']['screen_name'] + "\n")
                              self.tweets.insert(INSERT, "Text::: " + tweet['text'] + "\n")
                              self.tweets.insert(INSERT, "Created at::: " + tweet['created_at'] + "\n")
                              self.tweets.insert(INSERT, "--------------------------------------------------------------------\n\n")

                  except:
                  # read in a line is not in JSON format (sometimes error occured)
                      continue

          elif 'Date' in searchby:

              cursor = db.tweets.find()
              self.tweets.insert(INSERT, "    Showing Records searched by Data: " + keyword + "\n")
              self.tweets.insert(INSERT, "  ------------------------------------------\n\n")

              for document in cursor:
                      try:
                          tweet = document
                          if 'text' in tweet:
                              if keyword in tweet['created_at']:
                                  # only messages contains 'text' field is a tweet
                                  # textbox.Twitter1.tweets.insert(textbox.INSERT, tweet['text'] + "\n")
                                  self.tweets.insert(INSERT, "Screen Name::: " + tweet['user']['screen_name'] + "\n")
                                  self.tweets.insert(INSERT, "Text::: " + tweet['text'] + "\n")
                                  self.tweets.insert(INSERT, "Created at::: " + tweet['created_at'] + "\n")
                                  self.tweets.insert(INSERT,
                                                     "--------------------------------------------------------------------\n\n")

                                  hashtags = []
                                  for hashtag in tweet['entities']['hashtags']:
                                      hashtags.append(hashtag['text'])
                                  print hashtags

                      except:
                          # read in a line is not in JSON format (sometimes error occured)
                          continue

          elif 'Screen' in searchby:
              cursor = db.tweets.find()
              self.tweets.insert(INSERT, "    Showing Records searched by Screen Name: " + keyword + "\n")
              self.tweets.insert(INSERT, "  ---------------------------------------------\n\n")

              for document in cursor:
                  try:
                      tweet = document
                      if 'text' in tweet:
                          if keyword in tweet['user']['screen_name']:
                              # only messages contains 'text' field is a tweet
                              # textbox.Twitter1.tweets.insert(textbox.INSERT, tweet['text'] + "\n")
                              self.tweets.insert(INSERT, "Screen Name::: " + tweet['user']['screen_name'] + "\n")
                              self.tweets.insert(INSERT, "Text::: " + tweet['text'] + "\n")
                              self.tweets.insert(INSERT, "Created at::: " + tweet['created_at'] + "\n")
                              self.tweets.insert(INSERT,
                                                 "--------------------------------------------------------------------\n\n")
                              # self.tweets.insert(INSERT, "Hashtags::: " + tweet['[]'] + "\n\n")

                              hashtags = []
                              for hashtag in tweet['entities']['hashtags']:
                                  hashtags.append(hashtag['text'])
                              print hashtags

                  except:
                      # read in a line is not in JSON format (sometimes error occured)
                      continue

          elif 'Hashtag' in searchby:
              cursor = db.tweets.find()
              keyword = "#" + keyword
              self.tweets.insert(INSERT, "    Showing Records searched by Hashtag: " + keyword + "\n")
              self.tweets.insert(INSERT, "  ---------------------------------------------\n\n")

              for document in cursor:
                  try:
                      tweet = document
                      if 'text' in tweet:
                          if keyword in tweet['text']:
                              # only messages contains 'text' field is a tweet
                              # textbox.Twitter1.tweets.insert(textbox.INSERT, tweet['text'] + "\n")
                              self.tweets.insert(INSERT, "Screen Name::: " + tweet['user']['screen_name'] + "\n")
                              self.tweets.insert(INSERT, "Text::: " + tweet['text'] + "\n")
                              self.tweets.insert(INSERT, "Created at::: " + tweet['created_at'] + "\n")
                              self.tweets.insert(INSERT,
                                                 "--------------------------------------------------------------------\n\n")
                              # self.tweets.insert(INSERT, "Hashtags::: " + tweet['[]'] + "\n\n")

                              hashtags = []
                              for hashtag in tweet['entities']['hashtags']:
                                  hashtags.append(hashtag['text'])
                              print hashtags

                  except:
                      # read in a line is not in JSON format (sometimes error occured)
                      continue


def main():
    root =Tk()
    root.geometry("600x600")
    root.configure(background='#6699ff')
    twitter=Twitter(root)
    root.mainloop()
if __name__ == "__main__": main()